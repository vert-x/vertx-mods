def hello():
    print "hello"